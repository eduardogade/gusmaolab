#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/Users/egg/projects/Conversion_Logix_Takehome_Project}"

cd "$PROJECT_ROOT"
source .project-env
./scripts/check-project-env.sh
./scripts/check-terraform-config.sh

mkdir -p evidence/step-06
cd "$WORKING_FLYTE_CORE_DIR"

terraform init -backend-config=backend.gcs.hcl
terraform validate

terraform plan \
  -out=tfplan \
  2>&1 | tee "$PROJECT_ROOT/evidence/step-06/terraform-plan.txt"

terraform show -no-color tfplan \
  > "$PROJECT_ROOT/evidence/step-06/terraform-plan-readable.txt"

terraform show -json tfplan \
  > "$PROJECT_ROOT/evidence/step-06/terraform-plan.json"

echo "Plan generated. Review before any terraform apply."
